from django.db import models

class Estado(models.Model):
    id_estado = models.AutoField(primary_key=True)

    nome = models.CharField(
        max_length=100,
        null=False,
        blank=False
    )

    sigla = models.CharField(
        max_length=2,
        unique=True
    )

    def __str__(self):
        return f"{self.nome} ({self.sigla})"