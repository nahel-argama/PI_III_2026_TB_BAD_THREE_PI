from rest_framework import serializers
from .models import Estado


class EstadoSerializer(serializers.ModelSerializer):

    class Meta:
        model = Estado
        fields = [
            'id_estado',
            'nome',
            'sigla'
        ]

    def validate_sigla(self, value):
        if len(value) != 2:
            raise serializers.ValidationError("Sigla deve ter 2 caracteres")
        return value.upper()