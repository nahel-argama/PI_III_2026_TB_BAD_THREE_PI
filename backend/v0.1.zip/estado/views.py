from rest_framework import viewsets, mixins
from rest_framework.permissions import IsAuthenticated
from .models import Estado
from .serializers import EstadoSerializer


class EstadoViewSet(
    mixins.CreateModelMixin,
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
    mixins.UpdateModelMixin,
    viewsets.GenericViewSet
):
    queryset = Estado.objects.all()
    serializer_class = EstadoSerializer
    permission_classes = [IsAuthenticated]